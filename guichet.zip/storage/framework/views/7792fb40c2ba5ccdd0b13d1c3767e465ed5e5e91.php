<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<main id="main" class="main">

    <div class="pagetitle">
      <h1>Tableau de bord</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="#">Acceuil</a></li>
          <li class="breadcrumb-item active">Tableau de bord</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <section class="section dashboard">
      <div class="row">

        <!-- Left side columns -->
        <div class="col-lg-8">
          <div class="row">


            

            <!-- Recent Sales -->
            <div class="col-12">
              <div class="overflow-auto card recent-sales">

                <div class="card-body">
                  <h5 class="card-title">Liste des requérants</h5>

                  <table class="table table-borderless datatable">
                    <thead>

                         <tr>
                           <th scope="col">Requerant</th>
                           <th scope="col">Telephone</th>
                           <th scope="col">Email</th>
                           <th scope="col">Action</th>
                         </tr>

                    </thead>
                    <tbody>


                        <?php $__currentLoopData = $requerants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $requerant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                            <td><?php echo e($requerant->name); ?></td>
                            <td><?php echo e($requerant->telephone); ?></td>
                            <td><?php echo e($requerant->email); ?></td>
                            <td>

                                        <a href="" class="btn btn-warning"><i class="bi bi-pen-fill"></i></a>

                                        <a href="" class="btn btn-danger"><i class="bi bi-pen-fill"></i></a>

                            </td>


                        </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                  </table>

                </div>

              </div>
            </div><!-- End Recent Sales -->
          </div>
        </div><!-- End Left side columns -->

        <!-- Right side columns -->
      </div>
    </section>

  </main><!-- End #main -->

<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php /**PATH C:\xampp\htdocs\guichet\resources\views/profile.blade.php ENDPATH**/ ?>