<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<main id="main" class="main">
<section class="py-4 section align-items justify-content">
    <div class="py-4 row align-items justify-content">
      <div class="col-lg-8">
        <div class="card">
          <div class="card-body">

            

                            <!--
              This component uses @tailwindcss/forms

              yarn add @tailwindcss/forms
              npm install @tailwindcss/forms

              plugins: [require('@tailwindcss/forms')]
            -->

            <div class="mx-auto max-w-screen-xl px-4 py-16 sm:px-6 lg:px-8">
              <div class="mx-auto max-w-lg">
                <h1 class="text-center text-2xl font-bold text-indigo-600 sm:text-3xl">
                  Enrolement au FNPSS
                </h1>

                

                <form action="<?php echo e(route('enrolement.create')); ?>" class="row g-3" method="POST" enctype="multipart/form-data">
                  <?php echo csrf_field(); ?>
                  

                  <div>
                    <label for="email" class="text-sm font-medium">Lettre</label>

                    <div class="relative mt-1">
                      <input
                        type="file"
                        id="file"
                        name="lettre"
                        class="w-full rounded-lg border-gray-200 p-4 pr-12 text-sm shadow-sm"
                        placeholder="Chercher les fichiers"
                      />

                     
                    </div>
                  </div>

                  
                  
                  <div>
                    <label class="sr-only" for="message">Message</label>
                    <textarea
                      class="w-full rounded-lg border-gray-200 p-3 text-sm"
                      placeholder="Message"
                      rows="8"
                      id="message"
                    ></textarea>
                  </div>
                

                  <button
                    type="submit"
                    class="block w-full rounded-lg bg-red-600 px-5 py-3 text-sm font-medium text-white">
                    S'enroler maintenant
                  </button>

                  
                </form>
              </div>
            </div>


          </div>
        </div>

      </div>
    </div>
    
</section>

</main>



<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\guichet\resources\views/enrolement/create.blade.php ENDPATH**/ ?>