<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<main>
    <div class="container">

      

            <!--
        This component uses @tailwindcss/forms

        yarn add @tailwindcss/forms
        npm install @tailwindcss/forms

        plugins: [require('@tailwindcss/forms')]
      -->

      <div class="mx-auto max-w-screen-xl px-4 py-16 sm:px-6 lg:px-8">
        <div class="mx-auto max-w-lg">
          <h1 class="text-center text-2xl font-bold text-indigo-600 sm:text-3xl">
            Inscription à la plateforme de FNPSS
          </h1>

          <p class="mx-auto mt-4 max-w-md text-center text-gray-500">
            Ce portail vous permet d'effectuer toutes les opérations en ligne sans vous deplacer
          </p>

          <form method="POST" action="<?php echo e(route('register')); ?>" class="mt-6 mb-0 space-y-4 rounded-lg p-8 shadow-2xl">
            <?php echo csrf_field(); ?>
            <p class="text-lg font-medium"><b>Creer votre compte maintenant</b></p>

            <div>
              <label for="name" class="text-sm font-medium">Nom</label>

              <div class="relative mt-1">
                <input
                  type="text" name="name"
                  id="name"
                  class="w-full rounded-lg border-gray-200 p-4 pr-12 text-sm shadow-sm"
                  placeholder="Entrer votre nom"
                />
              </div>
            </div>

            <div>
              <label for="email" class="text-sm font-medium">Email</label>

              <div class="relative mt-1">
                <input
                  type="email" name="email"
                  id="email"
                  class="w-full rounded-lg border-gray-200 p-4 pr-12 text-sm shadow-sm"
                  placeholder="Entrer votre email"
                />
              </div>
            </div>

            <div>
              <label for="password" class="text-sm font-medium">Mot de passe</label>

              <div class="relative mt-1">
                <input
                  type="password" name="password"
                  id="password"
                  class="w-full rounded-lg border-gray-200 p-4 pr-12 text-sm shadow-sm"
                  placeholder="Veuillez entrer votre mot de passe"
                />
              </div>
            </div>

            <div>
              <label for="password" class="text-sm font-medium">Confirmation du mot de passe</label>

              <div class="relative mt-1">
                <input
                  type="password" name="password_confirmation"
                  id="password"
                  class="w-full rounded-lg border-gray-200 p-4 pr-12 text-sm shadow-sm"
                  placeholder="Veuillez entrer votre mot de passe"
                />
              </div>
            </div>

            <button
              type="submit"
              class="block w-full rounded-lg bg-indigo-600 px-5 py-3 text-sm font-medium text-white"
            >
                Creer un compte
            </button>

            <p class="text-center text-sm text-gray-500">
              Vous avez déjà un compte
              <a class="underline" href="<?php echo e(route('login')); ?>">Connectez-vous</a>
            </p>
          </form>
        </div>
      </div>


    </div>
  </main><!-- End #main -->

<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php /**PATH C:\xampp\htdocs\guichet\resources\views/auth/register.blade.php ENDPATH**/ ?>