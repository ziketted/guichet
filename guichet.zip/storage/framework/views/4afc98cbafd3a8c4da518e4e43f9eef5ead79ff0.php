<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<main id="main" class="main">
    <section class="py-4 section align-items-center justify-content-center">
        <div class="py-4 row align-items-center justify-content-center">
          <div class="col-lg-8">
            <div class="card">
              <div class="card-body">
                <!-- General Form Elements -->

                <?php $__currentLoopData = $profiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <form action="<?php echo e(route('profile.identiteupdate')); ?>" class="row g-3" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>

                        <h5 class="card-title">Identification de la structure</h5>
                        <div class="col-md-6">
                        <div class="form-floating">
                            <input
                                class="w-full rounded-lg border-gray-200 p-3 text-sm"
                                placeholder="Denomination"
                                type="text" value="<?php echo e($profile->denomination); ?>"
                                name="denomination"
                                id="formFile" required
                            />
                        </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-floating">
                                <input
                                    class="w-full rounded-lg border-gray-200 p-3 text-sm"
                                    placeholder="Sigle"
                                    type="text" value="<?php echo e($profile->sigle); ?>"
                                    name="sigle"
                                    id="formFile" required
                                />
                            </div>
                        </div>

                        <h5 class="card-title">Responsable de l'organisation</h5>
                        <div class="col-md-6">
                        <div class="form-floating">
                            
                                <input
                                    class="w-full rounded-lg border-gray-200 p-3 text-sm"
                                    placeholder="Nom"
                                    type="text" value="<?php echo e($profile->responsable_nom); ?>"
                                    name="responsable_nom"
                                    id="formFile" required
                                />
                        </div>
                        </div>

                        <div class="col-md-6">
                        <div class="form-floating">
                            <input
                                    class="w-full rounded-lg border-gray-200 p-3 text-sm"
                                    placeholder="PostNom"
                                    type="text" value="<?php echo e($profile->responsable_postnom); ?>"
                                    name="responsable_postnom"
                                    id="formFile" required
                                />
                        </div>
                        </div>
                        <div class="col-md-6">
                        <div class="form-floating">
                            
                                <input
                                    class="w-full rounded-lg border-gray-200 p-3 text-sm"
                                    placeholder="Prenom"
                                    type="text" value="<?php echo e($profile->responsable_prenom); ?>"
                                    name="responsable_prenom"
                                    id="formFile" required
                                />
                        </div>
                        </div>
                        <div class="col-md-6">
                        <div class="form-floating">
                                <input
                                    class="w-full rounded-lg border-gray-200 p-3 text-sm"
                                    placeholder="Fonction"
                                    type="text" value="<?php echo e($profile->responsable_fonction); ?>"
                                    name="responsable_fonction"
                                    id="formFile" required
                                />
                        </div>
                        </div>
                        <div class="col-md-6">
                        <div class="form-floating">
                                <input
                                    class="w-full rounded-lg border-gray-200 p-3 text-sm"
                                    placeholder="Téléphone"
                                    type="text" value="<?php echo e($profile->responsable_phone); ?>"
                                    name="responsable_phone"
                                    id="formFile" required
                                />
                        </div>
                        </div>
                        <div class="col-md-6">
                        <div class="form-floating">
                            <input
                                    class="w-full rounded-lg border-gray-200 p-3 text-sm"
                                    placeholder="Email"
                                    type="text" value="<?php echo e($profile->responsable_email); ?>"
                                    name="responsable_email"
                                    id="formFile" required
                                />
                        </div>
                        </div>

                        <div class="col-sm-6">
                        
                        <button
                            type="submit"
                            class="block w-full rounded-lg bg-red-600 px-5 py-3 text-sm font-medium text-white">
                                Mettre à jour
                        </button>
                        </div>

                    </form>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
            </div>

          </div>
        </div>
    </section>
    </main>

    

<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\guichet\resources\views/profiles/edit.blade.php ENDPATH**/ ?>