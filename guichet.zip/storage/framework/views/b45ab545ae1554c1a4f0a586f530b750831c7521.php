<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<main id="main" class="main">
<section class="py-4 section align-items justify-content">
    <div class="py-4 row align-items justify-content">
      <div class="col-lg-8">
        <div class="card">
          <div class="card-body">

            

                            <!--
              This component uses @tailwindcss/forms

              yarn add @tailwindcss/forms
              npm install @tailwindcss/forms

              plugins: [require('@tailwindcss/forms')]
            -->

            <div class="mx-auto max-w-screen-xl px-4 py-16 sm:px-6 lg:px-8">
              <div class="mx-auto max-w-lg">
                <h3 class="text-center text-2xl font-bold text-indigo-600 sm:text-3xl">
                  Paiement de l'enrolement
                </h3>
                <?php

                    $users = DB::table('users')
                    
                    ->where('id', $user_id)
                    ->get();
                ?>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
            <a
              class="relative block rounded-xl border border-gray-100 p-8 shadow-xl"
              href=""
            >
              <span
                class="absolute right-4 top-4 rounded-full bg-green-100 px-3 py-1.5 text-xs font-medium text-green-600"
              >
                Paiement
              </span>

              <div class="mt-4 text-gray-500 sm:pr-8">
                
                <h7 class="mt-4 text-xl font-bold text-gray-900">Nom : <?php echo e($user->name); ?></h7><br>
                <h7 class="mt-4 text-xl font-bold text-gray-900">Email : <?php echo e($user->email); ?></h7><br>
                <h7 class="mt-4 text-xl font-bold text-gray-900">Montant : 50 USD</h7>

                
              </div>
            </a><br>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                

                <form action="https://api.maxicashapp.com/PayEntryPost" method="POST">
                    <input type="hidden" name="PayType" value="MaxiCash">
                    <input type="hidden" name="Amount" value="5000">
                    <input type="hidden" name="Currency" value="MaxiDollar">
                    <input type="hidden" name="Telephone" value="0813579841">
                    <input type="hidden" name="Email" value="<?php echo e($user->email); ?>">

                    <input type="hidden" name="MerchantID" value="cffbf69177664b7595fe285527cc9ccd">
                    <input type="hidden" name="MerchantPassword" value="66267160e1c84713bd098395902fff19">
                    <input type="hidden" name="Language" value="En">
                    <input type="hidden" name="Reference" value="0001">
                    <input type="hidden" name="accepturl" value="https://www.google.fr/">
                    <input type="hidden" name="cancelurl" value="https://www.google.fr/">
                    <input type="hidden" name="declineurl" value="https://www.google.fr/">
                    <input type="hidden" name="notifyurl" value="https://www.google.fr/">

                    <button
                        type="submit"
                        class="block w-full rounded-lg bg-indigo-600 px-5 py-3 text-sm font-medium text-white">
                        Payer votre enrolement maintenant
                    </button>

                  </form>

              </div>
            </div>


          </div>
        </div>

      </div>
    </div>


</section>

</main>



<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\guichet\resources\views/enrolement/pay.blade.php ENDPATH**/ ?>