<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<main id="main" class="main">
    <section class="py-4 section align-items-center justify-content-center">
        <div class="py-4 row align-items-center justify-content-center">
          <div class="col-lg-8">
            <div class="card">
              <div class="card-body">
                <!-- General Form Elements -->
                <?php $__currentLoopData = $profiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <h5 class="card-title">Documents administratifs</h5>
                    <form action="<?php echo e(route('profile.updStatut')); ?>" class="row g-3" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php if(is_null($profile->doc_statut) || $profile->doc_statut=='' ): ?>

                        <div class="col-md-6">
                            <div class="mb-3 row">
                                <div>
                                    <label for="email" class="text-sm font-medium"><b>Modifiez vos statuts</b></label>
                
                                    <div class="relative mt-1">
                                      <input
                                        type="file"
                                        id="formFile"
                                        name="doc_statut"
                                        class="w-full rounded-lg border-gray-200 p-4 pr-12 text-sm shadow-sm"
                                        placeholder="Chercher les fichiers"
                                      />
                                    </div>
                                </div>
                                  
                            </div>
                            <div class="col-sm-7">
                                
                                <button
                                    type="submit"
                                    class="block w-full rounded-lg bg-red-600 px-5 py-3 text-sm font-medium text-white">
                                    Mettre à jour
                                </button>
                            </div>
                        </div>
                        <?php else: ?>
                            <div class="col-md-4 p-3">
                                <div class="mb-3 row">
                                    <div class="form-floating">
                                        <a href="<?php echo e(Storage::url($profile->doc_statut)); ?>" download="lettre">
                                            <h5>&nbsp;<i class="bi bi-download text-danger"></i>
                                                Télécharger le statut &nbsp;</h5></a>
                                    </div>
                                    
                                </div>
                            </div>

                            <div class="col-md-4">
                                <button class="btn btn-success">
                                    Modifier</button> </h5>
                            </div>
                        <?php endif; ?>
                    </form>
                    <form action="<?php echo e(route('profile.updAutorisation')); ?>" class="row g-3" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php if(is_null($profile->doc_autorisation) || $profile->doc_autorisation=='' ): ?>

                        <div class="col-md-6">
                            <div class="mb-3 row">
                                

                                <div>
                                    <label for="email" class="text-sm font-medium"><b>Modifiez votre autorisation de fonctionnement</b></label>
                
                                    <div class="relative mt-1">
                                      <input
                                        type="file"
                                        id="formFile"
                                        name="doc_autorisation"
                                        class="w-full rounded-lg border-gray-200 p-4 pr-12 text-sm shadow-sm"
                                        placeholder="Chercher les fichiers"
                                      />
                                    </div>
                                </div>

                            </div>
                            <div class="col-sm-7">
                                <button
                                    type="submit"
                                    class="block w-full rounded-lg bg-red-600 px-5 py-3 text-sm font-medium text-white">
                                    Mettre à jour
                                </button>
                            </div><br>
                        </div>
                        <hr>
                        <?php else: ?>
                        <div class="col-md-4 p-3">
                                <div class="mb-3 row">
                                <div class="form-floating">
                                    <a href="<?php echo e(Storage::url($profile->doc_autorisation)); ?>" download="lettre">
                                        <h5>&nbsp;<i class="bi bi-download text-danger"></i>
                                            Télécharger le statut &nbsp;</h5></a>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-4">
                            <button class="btn btn-success">
                                Modifier</button> </h5>
                        </div>
                        <?php endif; ?>
                    </form>
                <form action="<?php echo e(route('profile.upd_personnalite')); ?>" class="row g-3" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php if(is_null($profile->doc_personnalite) || $profile->doc_personnalite=='' ): ?>

                    <div class="col-md-6">
                        <div class="mb-3 row">
                            

                            <div>
                                <label for="email" class="text-sm font-medium"><b>Modifiez votre personnalité juridique</b></label>
            
                                <div class="relative mt-1">
                                  <input
                                    type="file"
                                    id="formFile"
                                    name="doc_personnalite"
                                    class="w-full rounded-lg border-gray-200 p-4 pr-12 text-sm shadow-sm"
                                    placeholder="Chercher les fichiers" required
                                  />
                                </div>
                            </div>

                        </div>
                        <div class="col-sm-7">
                            <button
                                type="submit"
                                class="block w-full rounded-lg bg-red-600 px-5 py-3 text-sm font-medium text-white">
                                Mettre à jour
                            </button>
                        </div><br>
                    </div>
                    <?php else: ?>
                    <div class="col-md-4 p-3">
                            <div class="mb-3 row">
                            <div class="form-floating">
                                <a href="<?php echo e(Storage::url($profile->doc_personnalite)); ?>" download="lettre">
                                    <h5>&nbsp;<i class="bi bi-download text-danger"></i>
                                        Télécharger le statut &nbsp;</h5></a>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <button class="btn btn-success">
                            Modifier</button> </h5>
                    </div>
                    <?php endif; ?>
                </form>
                <form action="<?php echo e(route('profile.upd_certificat')); ?>" class="row g-3" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php if(is_null($profile->doc_certificat) || $profile->doc_certificat=='' ): ?>

                    <div class="col-md-6">
                        <div class="mb-3 row">
                            

                            <div>
                                <label for="email" class="text-sm font-medium"><b>Modifiez votre Certificat</b></label>
            
                                <div class="relative mt-1">
                                  <input
                                    type="file"
                                    id="formFile"
                                    name="doc_certificat"
                                    class="w-full rounded-lg border-gray-200 p-4 pr-12 text-sm shadow-sm"
                                    placeholder="Chercher les fichiers" required
                                  />
            
                                  
                                </div>
                            </div>

                        </div>
                        <div class="col-sm-7">
                            <button
                                type="submit"
                                class="block w-full rounded-lg bg-red-600 px-5 py-3 text-sm font-medium text-white">
                                Mettre à jour
                            </button>
                        </div><br>
                    </div>
                    <hr>
                    <?php else: ?>
                    <div class="col-md-4 p-3">
                            <div class="mb-3 row">
                            <div class="form-floating">
                                <a href="<?php echo e(Storage::url($profile->doc_certificat)); ?>" download="lettre">
                                    <h5>&nbsp;<i class="bi bi-download text-danger"></i>
                                        Télécharger le statut &nbsp;</h5></a>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <button class="btn btn-success">
                            Modifier</button> </h5>
                    </div>
                    <?php endif; ?>
                </form>
                <form action="<?php echo e(route('profile.upd_convention')); ?>" class="row g-3" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php if(is_null($profile->doc_convention) || $profile->doc_convention=='' ): ?>

                    <div class="col-md-6">
                        <div class="mb-3 row">
                            

                            <div>
                                <label for="email" class="text-sm font-medium"><b>Modifiez votre convention de partenariat</b></label>
            
                                <div class="relative mt-1">
                                  <input
                                    type="file"
                                    id="formFile"
                                    name="doc_convention"
                                    class="w-full rounded-lg border-gray-200 p-4 pr-12 text-sm shadow-sm"
                                    placeholder="Chercher les fichiers" required
                                  />
            
                                  
                                </div>

                            </div>

                        </div>
                        <div class="col-sm-7">
                            <button
                                type="submit"
                                class="block w-full rounded-lg bg-red-600 px-5 py-3 text-sm font-medium text-white">
                                Mettre à jour
                            </button>
                        </div><br>
                    </div>
                    <?php else: ?>
                        <div class="col-md-4 p-3">
                                <div class="mb-3 row">
                                <div class="form-floating">
                                    <a href="<?php echo e(Storage::url($profile->doc_convention)); ?>" download="lettre">
                                        <h5>&nbsp;<i class="bi bi-download text-danger"></i>
                                            Télécharger la convention.  &nbsp;</h5></a>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <button class="btn btn-success">Modifier</button> </h5>
                        </div>
                    <?php endif; ?>
                </form>
                <form action="<?php echo e(route('profile.upd_accord')); ?>" class="row g-3" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php if(is_null($profile->doc_accord) || $profile->doc_accord=='' ): ?>

                    <div class="col-md-6">
                        <div class="mb-3 row">
                            

                            <div>
                                <label for="email" class="text-sm font-medium"><b>Modifiez votre accord cadre</b></label>
            
                                <div class="relative mt-1">
                                  <input
                                    type="file"
                                    id="formFile"
                                    name="doc_accord"
                                    class="w-full rounded-lg border-gray-200 p-4 pr-12 text-sm shadow-sm"
                                    placeholder="Chercher les fichiers" required
                                  />
            
                                  
                                </div>
                                
                            </div>
                        </div>
                        <div class="col-sm-7">
                            <button
                                type="submit"
                                class="block w-full rounded-lg bg-red-600 px-5 py-3 text-sm font-medium text-white">
                                Mettre à jour
                            </button>
                        </div><br>
                    </div>
                    <hr>
                    <?php else: ?>
                    <div class="col-md-4 p-3">
                            <div class="mb-3 row">
                            <div class="form-floating">
                                <a href="<?php echo e(Storage::url($profile->doc_accord)); ?>" download="lettre">
                                    <h5>&nbsp;<i class="bi bi-download text-danger"></i>
                                        Télécharger le statut &nbsp;</h5></a>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <button class="btn btn-success">
                            Modifier</button> </h5>
                    </div>
                    <?php endif; ?>
                </form>
                
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
            </div>

          </div>
        </div>
    </section>
    </main>

<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\guichet\resources\views/profiles/documents.blade.php ENDPATH**/ ?>