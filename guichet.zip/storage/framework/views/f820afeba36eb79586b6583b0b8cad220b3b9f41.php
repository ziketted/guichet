<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<main id="main" class="main">
    <section class="py-4 section align-items-center justify-content-center">
        <div class="py-4 row align-items-center justify-content-center">
          <div class="col-lg-8">
            <div class="card">
              <div class="card-body">
                <h5 class="card-title">Nos Objectifs</h5>

                <?php $__currentLoopData = $profiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <form action="<?php echo e(route('profile.upd_autres_infos')); ?>" class="row g-3" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>

                    <div class="col-md-10">
                      <div class="form-floating">
                          <textarea
                            class="w-full rounded-lg border-gray-200 p-3 text-sm"
                            placeholder=""
                            rows="8"
                            name="objectif_global"
                            id="message"
                          ><?php echo e($profile->objectif_global); ?></textarea>
                      </div>
                    </div>


                    <div class="col-md-10">
                        <div class="form-floating">
                            
                            <textarea
                            class="w-full rounded-lg border-gray-200 p-3 text-sm"
                            placeholder=""
                            rows="8"
                            name="objectif_specifique"
                            id="message"
                          ><?php echo e($profile->objectif_specifique); ?></textarea>
                        </div>
                    </div>

                    <div class="col-sm-4">
                      
                      <button
                          type="submit"
                          class="block w-full rounded-lg bg-indigo-600 px-5 py-3 text-sm font-medium text-white">
                              Mettre à jour
                      </button>
                    </div>
                </form><!-- End General Form Elements -->

                <!-- General Form Elements -->


              </div>
            </div>

          </div>
        </div>
    </section>
    </main>

<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\guichet\resources\views/profiles/autres_infos.blade.php ENDPATH**/ ?>