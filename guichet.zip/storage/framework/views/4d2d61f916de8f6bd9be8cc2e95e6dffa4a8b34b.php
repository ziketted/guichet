<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<main id="main" class="main">

    <div class="pagetitle">
      <h1>Enrolement</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="#">Acceuil</a></li>
          <li class="breadcrumb-item active">Enrolement</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <section class="section dashboard">
      <div class="row">

        <!-- Left side columns -->
        <div class="col-lg-8">
          <div class="row">


            


            


            




            <!-- Recent Sales -->
            <div class="col-12">
              <div class="overflow-auto card recent-sales">

                <div class="card-body">
                  <h5 class="card-title">Liste des enrolements</h5>

                  <table class="table table-borderless datatable">
                    <thead>
                      <tr>
                        <th scope="col">Requerant</th>
                        <th scope="col">Enrolement</th>
                        <th scope="col">Etat</th>
                        <th scope="col">Date</th>
                        <th scope="col">Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      
                    <?php $__currentLoopData = $enrolements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enrolement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($enrolement->name); ?></td>
                                <td> <a href="<?php echo e(Storage::url($enrolement->lettre)); ?>" download="lettre">
                                    <i class="bi bi-download text-gray"> Téléchargez la lettre</i></a></td>
                                <td><span class="badge bg-success"><?php echo e($enrolement->statut); ?></span></td>
                                <td><?php echo e($enrolement->created_at); ?></td>
                                <td>
                                    <a href="" class="btn btn-warning"><i class="bi bi-pen-fill"></i></a>
                                    <a href="" class="btn btn-danger"><i class="bi bi-trash"></i></a>
                                </td>
                            </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                  </table>

                </div>

              </div>
            </div><!-- End Recent Sales -->
          </div>
        </div><!-- End Left side columns -->

        <!-- Right side columns -->
      </div>
    </section>

  </main><!-- End #main -->

<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php /**PATH C:\xampp\htdocs\guichet\resources\views/admin/valid_enrolement.blade.php ENDPATH**/ ?>