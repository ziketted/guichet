<?php

namespace App\Http\Controllers;

use DateTime;
use App\Models\Exoneration;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Storage;
use App\Http\Requests\StoreExonerationRequest;
use App\Http\Requests\UpdateExonerationRequest;
use Illuminate\Filesystem\Filesystem;
class FonctionController extends Controller
{
    //
    public function creation_dossier($username){

    }
}
